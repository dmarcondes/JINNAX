#Functions to train NN
import jax
import jax.numpy as jnp
import optax
from alive_progress import alive_bar
import math
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import dill as pickle
from genree import bolstering as gb
from genree import kernel as gk
from jax import random
from jinnax import data as jd
import os

__docformat__ = "numpy"

#MSE
@jax.jit
def MSE(pred,true):
    """
    Mean square error
    ----------

    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    Returns
    -------
    mean square error
    """
    return (true - pred) ** 2

#MSE self-adaptative
@jax.jit
def MSE_SA(pred,true,w):
    """
    Selft-adaptative mean square error
    ----------

    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    wheight : jax.numpy.array

        A JAX numpy array with the weights

    c : float

        Hyperparameter

    Returns
    -------
    self-adaptative mean square error with sigmoid mask
    """
    return (w * (true - pred)) ** 2

#L2 error
@jax.jit
def L2error(pred,true):
    """
    L2-error
    ----------

    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    Returns
    -------
    L2-error
    """
    return jnp.sqrt(jnp.sum((true - pred)**2))/jnp.sqrt(jnp.sum(true ** 2))

#Simple fully connected architecture. Return the initial parameters and the function for the forward pass
def fconNN(width,activation = jax.nn.tanh,key = 0):
    """
    Initialize fully connected neural network
    ----------

    Parameters
    ----------
    width : list

        List with the layers width

    activation : jax.nn activation

        The activation function. Default jax.nn.tanh

    key : int

        Seed for parameters initialization. Default 0

    Returns
    -------
    dict with initial parameters and the function for the forward pass
    """
    #Initialize parameters with Glorot initialization
    initializer = jax.nn.initializers.glorot_normal()
    key = jax.random.split(jax.random.PRNGKey(key),len(width)-1) #Seed for initialization
    params = list()
    for key,lin,lout in zip(key,width[:-1],width[1:]):
        W = initializer(key,(lin,lout),jnp.float32)
        B = initializer(key,(1,lout),jnp.float32)
        params.append({'W':W,'B':B})

    #Define function for forward pass
    @jax.jit
    def forward(x,params):
        *hidden,output = params
        for layer in hidden:
            x = activation(x @ layer['W'] + layer['B'])
        return x @ output['W'] + output['B']

    #Return initial parameters and forward function
    return {'params': params,'forward': forward}

#Get activation from string
def get_activation(act):
    """
    Return activation function from string
    ----------

    Parameters
    ----------
    act : str

        Name of the activation function. Default 'tanh'

    Returns
    -------
    jax.nn activation function
    """
    if act == 'tanh':
        return jax.nn.tanh
    elif act == 'relu':
        return jax.nn.relu
    elif act == 'relu6':
        return jax.nn.relu6
    elif act == 'sigmoid':
        return jax.nn.sigmoid
    elif act == 'softplus':
        return jax.nn.softplus
    elif act == 'sparse_plus':
        return jx.nn.sparse_plus
    elif act == 'soft_sign':
        return jax.nn.soft_sign
    elif act == 'silu':
        return jax.nn.silu
    elif act == 'swish':
        return jax.nn.swish
    elif act == 'log_sigmoid':
        return jax.nn.log_sigmoid
    elif act == 'leaky_relu':
        return jax.xx.leaky_relu
    elif act == 'hard_sigmoid':
        return jax.nn.hard_sigmoid
    elif act == 'hard_silu':
        return jax.nn.hard_silu
    elif act == 'hard_swish':
        return jax.nn.hard_swish
    elif act == 'hard_tanh':
        return jax.nn.hard_tanh
    elif act == 'elu':
        return jax.nn.elu
    elif act == 'celu':
        return jax.nn.celu
    elif act == 'selu':
        return jax.nn.selu
    elif act == 'gelu':
        return jax.nn.gelu
    elif act == 'glu':
        return jax.nn.glu
    elif act == 'squareplus':
        return  jax.nn.squareplus
    elif act == 'mish':
        return jax.nn.mish

#Training PINN
def train_PINN(data,width,pde,test_data = None,epochs = 100,at_each = 10,activation = 'tanh',neumann = False,oper_neumann = False,sa = False,c = {'ws': 1,'wr': 1,'w0': 100,'wb': 1},inverse = False,initial_par = None,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,key = 0,epoch_print = 100,save = False,file_name = 'result_pinn',exp_decay = False,transition_steps = 1000,decay_rate = 0.9,ff = False):
    """
    Train a Physics-informed Neural Network
    ----------

    Parameters
    ----------
    data : dict

        Data generated by the jinnax.data.generate_PINNdata function

    width : list

        A list with the width of each layer

    pde : function

        The partial differential operator. Its arguments are u, x and t

    test_data : dict, None

        A dictionay with test data for L2 error calculation generated by the jinnax.data.generate_PINNdata function. Default None for not calculating L2 error

    epochs : int

        Number of training epochs. Default 100

    at_each : int

        Save results for epochs multiple of at_each. Default 10

    activation : str

        The name of the activation function of the neural network. Default 'tanh'

    neumann : logical

        Whether to consider Neumann boundary conditions

    oper_neumann : function

        Penalization of Neumann boundary conditions

    sa : logical

        Whether to consider self-adaptative PINN

    c : dict

        Dictionary with the hyperparameters of the self-adaptative sigmoid mask for the initial (w0), sensor (ws) and collocation (wr) points. The weights of the boundary points is fixed to 1

    inverse : logical

        Whether to estimate parameters of the PDE

    initial_par : jax.numpy.array

        Initial value of the parameters of the PDE in an inverse problem

    lr,b1,b2,eps,eps_root: float

        Hyperparameters of the Adam algorithm. Default lr = 0.001, b1 = 0.9, b2 = 0.999, eps = 1e-08, eps_root = 0.0

    key : int

        Seed for parameters initialization. Default 0

    epoch_print : int

        Number of epochs to calculate and print test errors. Default 100

    save : logical

        Whether to save the current parameters. Default False

    file_name : str

        File prefix to save the current parameters. Default 'result_pinn'

    exp_decay : logical

        Whether to consider exponential decay of learning rate. Default False

    transition_steps : int

        Number of steps for exponential decay. Default 1000

    decay_rate : float

        Rate of exponential decay. Default 0.9

    ff : logical

        Whether to consider Fourrier features

    Returns
    -------
    dict-like object with the estimated function, the estimated parameters, the neural network function for the forward pass and the training time
    """

    #Initialize architecture
    nnet = fconNN(width,get_activation(activation),key,ff)
    forward = nnet['forward']

    #Initialize self adaptative weights
    par_sa = {}
    if sa:
        #Initialize wheights close to zero
        ksa = jax.random.randint(jax.random.PRNGKey(key),(5,),1,1000000)
        if data['sensor'] is not None:
            par_sa.update({'ws': c['ws'] * jax.random.uniform(key = jax.random.PRNGKey(ksa[0]),shape = (data['sensor'].shape[0],1))})
        if data['initial'] is not None:
            par_sa.update({'w0': c['w0'] * jax.random.uniform(key = jax.random.PRNGKey(ksa[1]),shape = (data['initial'].shape[0],1))})
        if data['collocation'] is not None:
            par_sa.update({'wr': c['wr'] * jax.random.uniform(key = jax.random.PRNGKey(ksa[2]),shape = (data['collocation'].shape[0],1))})
        if data['boundary'] is not None:
            par_sa.update({'wb': c['wr'] * jax.random.uniform(key = jax.random.PRNGKey(ksa[3]),shape = (data['boundary'].shape[0],1))})

    #Store all parameters
    params = {'net': nnet['params'],'inverse': initial_par,'sa': par_sa}

    #Save config file
    if save:
        pickle.dump({'train_data': data,'epochs': epochs,'activation': activation,'init_params': params,'forward': forward,'width': width,'pde': pde,'lr': lr,'b1': b1,'b2': b2,'eps': eps,'eps_root': eps_root,'key': key,'inverse': inverse,'sa': sa},open(file_name + '_config.pickle','wb'), protocol = pickle.HIGHEST_PROTOCOL)

    #Define loss function
    if sa:
        #Define loss function
        @jax.jit
        def lf(params,x):
            loss = 0
            if x['sensor'] is not None:
                #Term that refers to sensor data
                loss = loss + jnp.mean(MSE_SA(forward(x['sensor'],params['net']),x['usensor'],params['sa']['ws']))
            if x['boundary'] is not None:
                if neumann:
                    #Neumann coditions
                    xb = x['boundary'][:,:-1].reshape((x['boundary'].shape[0],x['boundary'].shape[1] - 1))
                    tb = x['boundary'][:,-1].reshape((x['boundary'].shape[0],1))
                    loss = loss + jnp.mean(oper_neumann(lambda x,t: forward(jnp.append(x,t,1),params['net']),xb,tb,params['sa']['wb']))
                else:
                    #Term that refers to boundary data
                    loss = loss + jnp.mean(MSE_SA(forward(x['boundary'],params['net']),x['uboundary'],params['sa']['wb']))
            if x['initial'] is not None:
                #Term that refers to initial data
                loss = loss + jnp.mean(MSE_SA(forward(x['initial'],params['net']),x['uinitial'],params['sa']['w0']))
            if x['collocation'] is not None:
                #Term that refers to collocation points
                x_col = x['collocation'][:,:-1].reshape((x['collocation'].shape[0],x['collocation'].shape[1] - 1))
                t_col = x['collocation'][:,-1].reshape((x['collocation'].shape[0],1))
                if inverse:
                    loss = loss + jnp.mean(MSE_SA(pde(lambda x,t: forward(jnp.append(x,t,1),params['net']),x_col,t_col,params['inverse']),0,params['sa']['wr']))
                else:
                    loss = loss + jnp.mean(MSE_SA(pde(lambda x,t: forward(jnp.append(x,t,1),params['net']),x_col,t_col),0,params['sa']['wr']))
            return loss
    else:
        @jax.jit
        def lf(params,x):
            loss = 0
            if x['sensor'] is not None:
                #Term that refers to sensor data
                loss = loss + jnp.mean(MSE(forward(x['sensor'],params['net']),x['usensor']))
            if x['boundary'] is not None:
                if neumann:
                    #Neumann coditions
                    xb = x['boundary'][:,:-1].reshape((x['boundary'].shape[0],x['boundary'].shape[1] - 1))
                    tb = x['boundary'][:,-1].reshape((x['boundary'].shape[0],1))
                    loss = loss + jnp.mean(oper_neumann(lambda x,t: forward(jnp.append(x,t,1),params['net']),xb,tb))
                else:
                    #Term that refers to boundary data
                    loss = loss + jnp.mean(MSE(forward(x['boundary'],params['net']),x['uboundary']))
            if x['initial'] is not None:
                #Term that refers to initial data
                loss = loss + jnp.mean(MSE(forward(x['initial'],params['net']),x['uinitial']))
            if x['collocation'] is not None:
                #Term that refers to collocation points
                x_col = x['collocation'][:,:-1].reshape((x['collocation'].shape[0],x['collocation'].shape[1] - 1))
                t_col = x['collocation'][:,-1].reshape((x['collocation'].shape[0],1))
                if inverse:
                    loss = loss + jnp.mean(MSE(pde(lambda x,t: forward(jnp.append(x,t,1),params['net']),x_col,t_col,params['inverse']),0))
                else:
                    loss = loss + jnp.mean(MSE(pde(lambda x,t: forward(jnp.append(x,t,1),params['net']),x_col,t_col),0))
            return loss

    #Initialize Adam Optmizer
    if exp_decay:
        lr = optax.exponential_decay(lr,transition_steps,decay_rate)
    optimizer = optax.adam(lr,b1,b2,eps,eps_root)
    opt_state = optimizer.init(params)

    #Define the gradient function
    grad_loss = jax.jit(jax.grad(lf,0))

    #Define update function
    @jax.jit
    def update(opt_state,params,x):
        #Compute gradient
        grads = grad_loss(params,x)
        #Invert gradient of self-adaptative wheights
        if sa:
            for w in grads['sa']:
                grads['sa'][w] = - grads['sa'][w]
        #Calculate parameters updates
        updates, opt_state = optimizer.update(grads, opt_state)
        #Update parameters
        params = optax.apply_updates(params, updates)
        #Return state of optmizer and updated parameters
        return opt_state,params

    ###Training###
    t0 = time.time()
    #Initialize alive_bar for tracing in terminal
    with alive_bar(epochs) as bar:
        #For each epoch
        for e in range(epochs):
            #Update optimizer state and parameters
            opt_state,params = update(opt_state,params,data)
            #After epoch_print epochs
            if e % epoch_print == 0:
                #Compute elapsed time and current error
                l = 'Time: ' + str(round(time.time() - t0)) + ' s Loss: ' + str(jnp.round(lf(params,data),6))
                #If there is test data, compute current L2 error
                if test_data is not None:
                    #Compute L2 error
                    l2_test = L2error(forward(test_data['xt'],params['net']),test_data['u']).tolist()
                    l = l + ' L2 error: ' + str(jnp.round(l2_test,6))
                if inverse:
                    l = l + ' Parameter: ' + str(jnp.round(params['inverse'].tolist(),6))
                #Print
                print(l)
            if ((e % at_each == 0 and at_each != epochs) or e == epochs - 1) and save:
                #Save current parameters
                pickle.dump({'params': params,'width': width,'time': time.time() - t0,'loss': lf(params,data)},open(file_name + '_epoch' + str(e).rjust(6, '0') + '.pickle','wb'), protocol = pickle.HIGHEST_PROTOCOL)
            #Update alive_bar
            bar()
    #Define estimated function
    def u(xt):
        return forward(xt,params['net'])

    return {'u': u,'params': params,'forward': forward,'time': time.time() - t0}

#Process result
def process_result(test_data,fit,train_data,plot = True,plot_test = True,times = 5,d2 = True,save = False,show = True,file_name = 'result_pinn',print_res = True,p = 1):
    """
    Process the results of a Physics-informed Neural Network
    ----------

    Parameters
    ----------
    test_data : dict

        A dictionay with test data for L2 error calculation generated by the jinnax.data.generate_PINNdata function

    fit : function

        The fitted function

    train_data : dict

        Training data generated by the jinnax.data.generate_PINNdata

    plot : logical

        Whether to generate plots comparing the exact and estimated solutions when the spatial dimension is one. Default True

    plot_test : logical

        Whether to plot the test data. Default True

    times : int

        Number of points along the time interval to plot. Default 5

    d2 : logical

        Whether to plot 2D plot when the spatial dimension is one. Default True

    save : logical

        Whether to save the plots. Default False

    show : logical

        Whether to show the plots. Default True

    file_name : str

        File prefix to save the plots. Default 'result_pinn'

    print_res : logical

        Whether to print the L2 error. Default True

    p : int

        Output dimension. Default 1

    Returns
    -------
    pandas data frame with L2 and MSE errors
    """

    #Dimension
    d = test_data['xt'].shape[1] - 1

    #Number of plots multiple of 5
    times = 5 * round(times/5.0)

    #Data
    td = get_train_data(train_data)
    xt_train = td['x']
    u_train = td['y']
    upred_train = fit(xt_train)
    upred_test = fit(test_data['xt'])

    #Results
    l2_error_test = L2error(upred_test,test_data['u']).tolist()
    MSE_test = jnp.mean(MSE(upred_test,test_data['u'])).tolist()
    l2_error_train = L2error(upred_train,u_train).tolist()
    MSE_train = jnp.mean(MSE(upred_train,u_train)).tolist()

    df = pd.DataFrame(np.array([l2_error_test,MSE_test,l2_error_train,MSE_train]).reshape((1,4)),
        columns=['l2_error_test','MSE_test','l2_error_train','MSE_train'])
    if print_res:
        print('L2 error test: ' + str(jnp.round(l2_error_test,6)) + ' L2 error train: ' + str(jnp.round(l2_error_train,6)) + ' MSE error test: ' + str(jnp.round(MSE_test,6)) + ' MSE error train: ' + str(jnp.round(MSE_train,6)) )

    #Plots
    if d == 1 and p ==1 and plot:
        plot_pinn1D(times,test_data['xt'],test_data['u'],upred_test,d2,save,show,file_name)
    elif p == 2 and plot:
        plot_pinn_out2D(times,test_data['xt'],test_data['u'],upred_test,save,show,file_name,plot_test)

    return df

#Plot results for d = 1
def plot_pinn1D(times,xt,u,upred,d2 = True,save = False,show = True,file_name = 'result_pinn',title_1d = '',title_2d = ''):
    """
    Plot the prediction of a 1D PINN
    ----------

    Parameters
    ----------
    times : int

        Number of points along the time interval to plot. Default 5

    xt : jax.numpy.array

        Test data xt array

    u : jax.numpy.array

        Test data u(x,t) array

    upred : jax.numpy.array

        Predicted upred(x,t) array on test data

    d2 : logical

        Whether to plot 2D plot. Default True

    save : logical

        Whether to save the plots. Default False

    show : logical

        Whether to show the plots. Default True

    file_name : str

        File prefix to save the plots. Default 'result_pinn'

    title_1d : str

        Title of 1D plot

    title_2d : str

        Title of 2D plot

    Returns
    -------
    None
    """
    #Initialize
    fig, ax = plt.subplots(int(times/5),5,figsize = (10*int(times/5),3*int(times/5)))
    tlo = jnp.min(xt[:,-1])
    tup = jnp.max(xt[:,-1])
    ylo = jnp.min(u)
    ylo = ylo - 0.1*jnp.abs(ylo)
    yup = jnp.max(u)
    yup = yup + 0.1*jnp.abs(yup)
    k = 0
    t_values = np.linspace(tlo,tup,times)

    #Create
    for i in range(int(times/5)):
        for j in range(5):
            if k < len(t_values):
                t = t_values[k]
                t = xt[jnp.abs(xt[:,-1] - t) == jnp.min(jnp.abs(xt[:,-1] - t)),-1][0].tolist()
                x_plot = xt[xt[:,-1] == t,:-1]
                y_plot = upred[xt[:,-1] == t,:]
                u_plot = u[xt[:,-1] == t,:]
                if int(times/5) > 1:
                    ax[i,j].plot(x_plot[:,0],u_plot[:,0],'b-',linewidth=2,label='Exact')
                    ax[i,j].plot(x_plot[:,0],y_plot,'r--',linewidth=2,label='Prediction')
                    ax[i,j].set_title('$t = %.2f$' % (t),fontsize=10)
                    ax[i,j].set_xlabel(' ')
                    ax[i,j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                else:
                    ax[j].plot(x_plot[:,0],u_plot[:,0],'b-',linewidth=2,label='Exact')
                    ax[j].plot(x_plot[:,0],y_plot,'r--',linewidth=2,label='Prediction')
                    ax[j].set_title('$t = %.2f$' % (t),fontsize=10)
                    ax[j].set_xlabel(' ')
                    ax[j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                k = k + 1

    #Title
    fig.suptitle(title_1d)
    fig.tight_layout()

    #Show and save
    fig = plt.gcf()
    if show:
        plt.show()
    if save:
        fig.savefig(file_name + '_slices.png')
    plt.close()

    #2d plot
    if d2:
        #Initialize
        fig, ax = plt.subplots(1,2)
        l1 = jnp.unique(xt[:,-1]).shape[0]
        l2 = jnp.unique(xt[:,0]).shape[0]

        #Create
        ax[0].pcolormesh(xt[:,-1].reshape((l2,l1)),xt[:,0].reshape((l2,l1)),u[:,0].reshape((l2,l1)),cmap = 'RdBu',vmin = ylo.tolist(),vmax = yup.tolist())
        ax[0].set_title('Exact')
        ax[1].pcolormesh(xt[:,-1].reshape((l2,l1)),xt[:,0].reshape((l2,l1)),upred[:,0].reshape((l2,l1)),cmap = 'RdBu',vmin = ylo.tolist(),vmax = yup.tolist())
        ax[1].set_title('Predicted')

        #Title
        fig.suptitle(title_2d)
        fig.tight_layout()

        #Show and save
        fig = plt.gcf()
        if show:
            plt.show()
        if save:
            fig.savefig(file_name + '_2d.png')
        plt.close()

#Plot results for d = 1
def plot_pinn_out2D(times,xt,u,upred,save = False,show = True,file_name = 'result_pinn',title = '',plot_test = True):
    """
    Plot the prediction of a PINN with 2D output
    ----------
    Parameters
    ----------
    times : int

        Number of points along the time interval to plot. Default 5

    xt : jax.numpy.array

        Test data xt array

    u : jax.numpy.array

        Test data u(x,t) array

    upred : jax.numpy.array

        Predicted upred(x,t) array on test data

    save : logical

        Whether to save the plots. Default False

    show : logical

        Whether to show the plots. Default True

    file_name : str

        File prefix to save the plots. Default 'result_pinn'

    title : str

        Title of plot

    plot_test : logical

        Whether to plot the test data. Default True

    Returns
    -------
    None
    """
    #Initialize
    fig, ax = plt.subplots(int(times/5),5,figsize = (10*int(times/5),3*int(times/5)))
    tlo = jnp.min(xt[:,-1])
    tup = jnp.max(xt[:,-1])
    xlo = jnp.min(u[:,0])
    xlo = xlo - 0.1*jnp.abs(xlo)
    xup = jnp.max(u[:,0])
    xup = xup + 0.1*jnp.abs(xup)
    ylo = jnp.min(u[:,1])
    ylo = ylo - 0.1*jnp.abs(ylo)
    yup = jnp.max(u[:,1])
    yup = yup + 0.1*jnp.abs(yup)
    k = 0
    t_values = np.linspace(tlo,tup,times)

    #Create
    for i in range(int(times/5)):
        for j in range(5):
            if k < len(t_values):
                t = t_values[k]
                t = xt[jnp.abs(xt[:,-1] - t) == jnp.min(jnp.abs(xt[:,-1] - t)),-1][0].tolist()
                xpred_plot = upred[xt[:,-1] == t,0]
                ypred_plot = upred[xt[:,-1] == t,1]
                if plot_test:
                    x_plot = u[xt[:,-1] == t,0]
                    y_plot = u[xt[:,-1] == t,1]
                if int(times/5) > 1:
                    if plot_test:
                        ax[i,j].plot(x_plot,y_plot,'b-',linewidth=2,label='Exact')
                    ax[i,j].plot(xpred_plot,ypred_plot,'r-',linewidth=2,label='Prediction')
                    ax[i,j].set_title('$t = %.2f$' % (t),fontsize=10)
                    ax[i,j].set_xlabel(' ')
                    ax[i,j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                else:
                    if plot_test:
                        ax[j].plot(x_plot,y_plot,'b-',linewidth=2,label='Exact')
                    ax[j].plot(xpred_plot,ypred,'r-',linewidth=2,label='Prediction')
                    ax[j].set_title('$t = %.2f$' % (t),fontsize=10)
                    ax[j].set_xlabel(' ')
                    ax[j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                k = k + 1

    #Title
    fig.suptitle(title)
    fig.tight_layout()

    #Show and save
    fig = plt.gcf()
    if show:
        plt.show()
    if save:
        fig.savefig(file_name + '_slices.png')
    plt.close()

#Get train data in one array
def get_train_data(train_data):
    """
    Process training sample
    ----------

    Parameters
    ----------
    train_data : dict

        A dictionay with train data generated by the jinnax.data.generate_PINNdata function

    Returns
    -------
    dict with the processed training data
    """
    xdata = None
    ydata = None
    xydata = None
    if train_data['sensor'] is not None:
        sensor_sample = train_data['sensor'].shape[0]
        xdata = train_data['sensor']
        ydata = train_data['usensor']
        xydata = jnp.column_stack((train_data['sensor'],train_data['usensor']))
    else:
        sensor_sample = 0
    if train_data['boundary'] is not None:
        boundary_sample = train_data['boundary'].shape[0]
        if xdata is not None:
            xdata = jnp.vstack((xdata,train_data['boundary']))
            ydata = jnp.vstack((ydata,train_data['uboundary']))
            xydata = jnp.vstack((xydata,jnp.column_stack((train_data['boundary'],train_data['uboundary']))))
        else:
            xdata = train_data['boundary']
            ydata = train_data['uboundary']
            xydata = jnp.column_stack((train_data['boundary'],train_data['uboundary']))
    else:
        boundary_sample = 0
    if train_data['initial'] is not None:
        initial_sample = train_data['initial'].shape[0]
        if xdata is not None:
            xdata = jnp.vstack((xdata,train_data['initial']))
            ydata = jnp.vstack((ydata,train_data['uinitial']))
            xydata = jnp.vstack((xydata,jnp.column_stack((train_data['initial'],train_data['uinitial']))))
        else:
            xdata = train_data['initial']
            ydata = train_data['uinitial']
            xydata = jnp.column_stack((train_data['initial'],train_data['uinitial']))
    else:
        initial_sample = 0
    if train_data['collocation'] is not None:
        collocation_sample = train_data['collocation'].shape[0]
    else:
        collocation_sample = 0

    return {'xy': xydata,'x': xdata,'y': ydata,'sensor_sample': sensor_sample,'boundary_sample': boundary_sample,'initial_sample': initial_sample,'collocation_sample': collocation_sample}

#Process training
def process_training(test_data,file_name,at_each = 100,bolstering = True,mc_sample = 10000,save = False,file_name_save = 'result_pinn',key = 0,ec = 1e-6,lamb = 1):
    """
    Process the training of a Physics-informed Neural Network
    ----------

    Parameters
    ----------
    test_data : dict

        A dictionay with test data for L2 error calculation generated by the jinnax.data.generate_PINNdata function

    file_name : str

        Name of the files saved during training

    at_each : int

        Compute results for epochs multiple of at_each. Default 100

    bolstering : logical

        Whether to compute bolstering mean square error. Default True

    mc_sample : int

        Number of sample for Monte Carlo integration in bolstering. Default 10000

    save : logical

        Whether to save the training results. Default False

    file_name_save : str

        File prefix to save the plots and the L2 error. Default 'result_pinn'

    key : int

        Key for random samples in bolstering. Default 0

    ec : float

        Stopping criteria error for EM algorithm in bolstering. Default 1e-6

    lamb : float

        Hyperparameter of EM algorithm in bolstering. Default 1

    Returns
    -------
    pandas data frame with training results
    """
    #Config
    config = pickle.load(open(file_name + '_config.pickle', 'rb'))
    epochs = config['epochs']
    train_data = config['train_data']
    forward = config['forward']

    #Get train data
    td = get_train_data(train_data)
    xydata = td['xy']
    xdata = td['x']
    ydata = td['y']
    sensor_sample = td['sensor_sample']
    boundary_sample = td['boundary_sample']
    initial_sample = td['initial_sample']
    collocation_sample = td['collocation_sample']

    #Generate keys
    if bolstering:
        keys = jax.random.split(jax.random.PRNGKey(key),epochs)

    #Initialize loss
    train_mse = []
    test_mse = []
    train_L2 = []
    test_L2 = []
    bolstX = []
    bolstXY = []
    loss = []
    time = []
    ep = []

    #Process training
    with alive_bar(epochs) as bar:
        for e in range(epochs):
            if (e % at_each == 0 and at_each != epochs) or e == epochs - 1:
                ep = ep + [e]

                #Read parameters
                params = pickle.load(open(file_name + '_epoch' + str(e).rjust(6, '0') + '.pickle','rb'))

                #Time
                time = time + [params['time']]

                #Define learned function
                def psi(x):
                    return forward(x,params['params']['net'])

                #Train MSE and L2
                if xdata is not None:
                    train_mse = train_mse + [jnp.mean(MSE(psi(xdata),ydata)).tolist()]
                    train_L2 = train_L2 + [L2error(psi(xdata),ydata).tolist()]
                else:
                    train_mse = train_mse + [None]
                    train_L2 = train_L2 + [None]

                #Test MSE and L2
                test_mse = test_mse + [jnp.mean(MSE(psi(test_data['xt']),test_data['u'])).tolist()]
                test_L2 = test_L2 + [L2error(psi(test_data['xt']),test_data['u']).tolist()]

                #Bolstering
                if bolstering:
                    bX = []
                    bXY = []
                    for method in ['chi','mm','mpe']:
                        kxy = gk.kernel_estimator(data = xydata,key = keys[e,0],method = method,lamb = lamb,ec = ec,psi = psi)
                        kx = gk.kernel_estimator(data = xdata,key = keys[e,0],method = method,lamb = lamb,ec = ec,psi = psi)
                        bX = bX + [gb.bolstering(psi,xdata,ydata,kx,key = keys[e,0],mc_sample = mc_sample).tolist()]
                        bXY = bXY + [gb.bolstering(psi,xdata,ydata,kxy,key = keys[e,0],mc_sample = mc_sample).tolist()]
                    for bias in [1/jnp.sqrt(xdata.shape[0]),1/xdata.shape[0],1/(xdata.shape[0] ** 2),1/(xdata.shape[0] ** 3),1/(xdata.shape[0] ** 4)]:
                        kx = gk.kernel_estimator(data = xydata,key = keys[e,0],method = 'hessian',lamb = lamb,ec = ec,psi = psi,bias = bias)
                        bX = bX + [gb.bolstering(psi,xdata,ydata,kx,key = keys[e,0],mc_sample = mc_sample).tolist()]
                    bolstX = bolstX + [bX]
                    bolstXY = bolstXY + [bXY]
                else:
                    bolstX = bolstX + [None]
                    bolstXY = bolstXY + [None]

                #Loss
                loss = loss + [params['loss'].tolist()]

                #Delete
                del params, psi
            #Update alive_bar
            bar()

    #Bolstering results
    if bolstering:
        bolstX = jnp.array(bolstX)
        bolstXY = jnp.array(bolstXY)

    #Create data frame
    if bolstering:
        df = pd.DataFrame(np.column_stack([ep,time,[sensor_sample] * len(ep),[boundary_sample] * len(ep),[initial_sample] * len(ep),[collocation_sample] * len(ep),loss,
            train_mse,test_mse,train_L2,test_L2,bolstX[:,0],bolstXY[:,0],bolstX[:,1],bolstXY[:,1],bolstX[:,2],bolstXY[:,2],bolstX[:,3],bolstX[:,4],bolstX[:,5],bolstX[:,6],bolstX[:,7]]),
            columns=['epoch','training_time','sensor_sample','boundary_sample','initial_sample','collocation_sample','loss','train_mse','test_mse','train_L2','test_L2','bolstX_chi','bolstXY_chi','bolstX_mm','bolstXY_mm','bolstX_mpe','bolstXY_mpe','bolstHessian_sqrtn','bolstHessian_n','bolstHessian_n2','bolstHessian_n3','bolstHessian_n4'])
    else:
        df = pd.DataFrame(np.column_stack([ep,time,[sensor_sample] * len(ep),[boundary_sample] * len(ep),[initial_sample] * len(ep),[collocation_sample] * len(ep),loss,
            train_mse,test_mse,train_L2,test_L2]),
            columns=['epoch','training_time','sensor_sample','boundary_sample','initial_sample','collocation_sample','loss','train_mse','test_mse','train_L2','test_L2'])
    if save:
        df.to_csv(file_name_save + '.csv',index = False)

    return df

#Demo video for training1D PINN
def demo_train_pinn1D(test_data,file_name,at_each = 100,times = 5,d2 = True,file_name_save = 'result_pinn_demo',title = '',framerate = 10):
    """
    Demo video with the training of a 1D PINN
    ----------

    Parameters
    ----------
    test_data : dict

        A dictionay with test data for L2 error calculation generated by the jinnax.data.generate_PINNdata function

    file_name : str

        Name of the files saved during training

    at_each : int

        Compute results for epochs multiple of at_each. Default 100

    times : int

        Number of points along the time interval to plot. Default 5

    d2 : logical

        Whether to make video demo of 2D plot. Default True

    file_name_save : str

        File prefix to save the plots and videos. Default 'result_pinn_demo'

    title : str

        Title for plots

    framerate : int

        Framerate for video. Default 10

    Returns
    -------
    None
    """
    #Config
    with open(file_name + '_config.pickle', 'rb') as file:
        config = pickle.load(file)
    epochs = config['epochs']
    train_data = config['train_data']
    forward = config['forward']

    #Get train data
    td = get_train_data(train_data)
    xt = td['x']
    u = td['y']

    #Create folder to save plots
    os.system('mkdir ' + file_name_save)

    #Create images
    k = 1
    with alive_bar(epochs) as bar:
        for e in range(epochs):
            if e % at_each == 0 or e == epochs - 1:
                #Read parameters
                params = pd.read_pickle(file_name + '_epoch' + str(e).rjust(6, '0') + '.pickle')

                #Define learned function
                def psi(x):
                    return forward(x,params['params']['net'])

                #Compute L2 train, L2 test and loss
                loss = params['loss']
                L2_train = L2error(psi(xt),u)
                L2_test = L2error(psi(test_data['xt']),test_data['u'])
                title_epoch = title + ' Epoch = ' + str(e) + ' L2 train = ' + str(round(L2_train,6)) + ' L2 test = ' + str(round(L2_test,6))

                #Save plot
                plot_pinn1D(times,test_data['xt'],test_data['u'],psi(test_data['xt']),d2,save = True,show = False,file_name = file_name_save + '/' + str(k),title_1d = title_epoch,title_2d = title_epoch)
                k = k + 1

                #Delete
                del params, psi, loss, L2_train, L2_test, title_epoch
            #Update alive_bar
            bar()
    #Create demo video
    os.system('ffmpeg -framerate ' + str(framerate) + ' -i ' + file_name_save + '/' + '%00d_slices.png -c:v libx264 -profile:v high -crf 20 -pix_fmt yuv420p ' + file_name_save + '/' + file_name_save + '_slices.mp4')
    if d2:
        os.system('ffmpeg -framerate ' + str(framerate) + ' -i ' + file_name_save + '/' + '%00d_2d.png -c:v libx264 -profile:v high -crf 20 -pix_fmt yuv420p ' + file_name_save + '/' + file_name_save + '_2d.mp4')

#Demo in time for 1D PINN
def demo_time_pinn1D(test_data,file_name,epochs,file_name_save = 'result_pinn_time_demo',title = '',framerate = 10):
    """
    Demo video with the time evolution of a 1D PINN
    ----------

    Parameters
    ----------
    test_data : dict

        A dictionay with test data for L2 error calculation generated by the jinnax.data.generate_PINNdata function

    file_name : str

        Name of the files saved during training

    epochs : list

        Which training epochs to plot

    file_name_save : str

        File prefix to save the plots and video. Default 'result_pinn_time_demo'

    title : str

        Title for plots

    framerate : int

        Framerate for video. Default 10

    Returns
    -------
    None
    """
    #Config
    with open(file_name + '_config.pickle', 'rb') as file:
        config = pickle.load(file)
    train_data = config['train_data']
    forward = config['forward']

    #Create folder to save plots
    os.system('mkdir ' + file_name_save)

    #Plot parameters
    tdom = jnp.unique(test_data['xt'][:,-1])
    ylo = jnp.min(test_data['u'])
    ylo = ylo - 0.1*jnp.abs(ylo)
    yup = jnp.max(test_data['u'])
    yup = yup + 0.1*jnp.abs(yup)

    #Open PINN for each epoch
    results = []
    upred = []
    for e in epochs:
        tmp = pd.read_pickle(file_name + '_epoch' + str(e).rjust(6, '0') + '.pickle')
        results = results + [tmp]
        upred = upred + [forward(test_data['xt'],tmp['params']['net'])]

    #Create images
    k = 1
    with alive_bar(len(tdom)) as bar:
        for t in tdom:
            #Test data
            xt_step = test_data['xt'][test_data['xt'][:,-1] == t]
            u_step = test_data['u'][test_data['xt'][:,-1] == t]
            #Initialize plot
            if len(epochs) > 1:
                fig, ax = plt.subplots(int(len(epochs)/2),2,figsize = (10,5*len(epochs)/2))
            else:
                fig, ax = plt.subplots(1,1,figsize = (10,5))
            #Create
            index = 0
            if int(len(epochs)/2) > 1:
                for i in range(int(len(epochs)/2)):
                    for j in range(min(2,len(epochs))):
                        upred_step = upred[index][test_data['xt'][:,-1] == t]
                        ax[i,j].plot(xt_step[:,0],u_step[:,0],'b-',linewidth=2,label='Exact')
                        ax[i,j].plot(xt_step[:,0],upred_step[:,0],'r--',linewidth=2,label='Prediction')
                        ax[i,j].set_title('Epoch = ' + str(epochs[index]),fontsize=10)
                        ax[i,j].set_xlabel(' ')
                        ax[i,j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                        index = index + 1
            elif len(epochs) > 1:
                for j in range(2):
                    upred_step = upred[index][test_data['xt'][:,-1] == t]
                    ax[j].plot(xt_step[:,0],u_step[:,0],'b-',linewidth=2,label='Exact')
                    ax[j].plot(xt_step[:,0],upred_step[:,0],'r--',linewidth=2,label='Prediction')
                    ax[j].set_title('Epoch = ' + str(epochs[index]),fontsize=10)
                    ax[j].set_xlabel(' ')
                    ax[j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                    index = index + 1
            else:
                upred_step = upred[index][test_data['xt'][:,-1] == t]
                ax.plot(xt_step[:,0],u_step[:,0],'b-',linewidth=2,label='Exact')
                ax.plot(xt_step[:,0],upred_step[:,0],'r--',linewidth=2,label='Prediction')
                ax.set_title('Epoch = ' + str(epochs[index]),fontsize=10)
                ax.set_xlabel(' ')
                ax.set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                index = index + 1


            #Title
            fig.suptitle(title + 't = ' + str(round(t,4)))
            fig.tight_layout()

            #Show and save
            fig = plt.gcf()
            fig.savefig(file_name_save + '/' + str(k) + '.png')
            k = k + 1
            plt.close()
            bar()

    #Create demo video
    os.system('ffmpeg -framerate ' + str(framerate) + ' -i ' + file_name_save + '/' + '%00d.png -c:v libx264 -profile:v high -crf 20 -pix_fmt yuv420p ' + file_name_save + '/' + file_name_save + '_time_demo.mp4')

#Demo in time for 2D PINN
def demo_time_pinn2D(test_data,file_name,epochs,file_name_save = 'result_pinn_time_demo',title = '',framerate = 10,ffmpeg = 'ffmpeg'):
    """
    Demo video with the time evolution of a 2D PINN
    ----------
    Parameters
    ----------
    test_data : dict

        A dictionay with test data for L2 error calculation generated by the jinnax.data.generate_PINNdata function

    file_name : str

        Name of the files saved during training

    epochs : list

        Which training epochs to plot

    file_name_save : str

        File prefix to save the plots and video. Default 'result_pinn_time_demo'

    title : str

        Title for plots

    framerate : int

        Framerate for video. Default 10

    ffmpeg : str

        Path to ffmpeg

    Returns
    -------
    None
    """
    #Config
    with open(file_name + '_config.pickle', 'rb') as file:
        config = pickle.load(file)
    train_data = config['train_data']
    forward = config['forward']

    #Create folder to save plots
    os.system('mkdir ' + file_name_save)

    #Plot parameters
    tdom = jnp.unique(test_data['xt'][:,-1])
    ylo = jnp.min(test_data['u'])
    ylo = ylo - 0.1*jnp.abs(ylo)
    yup = jnp.max(test_data['u'])
    yup = yup + 0.1*jnp.abs(yup)

    #Open PINN for each epoch
    results = []
    upred = []
    for e in epochs:
        tmp = pd.read_pickle(file_name + '_epoch' + str(e).rjust(6, '0') + '.pickle')
        results = results + [tmp]
        upred = upred + [forward(test_data['xt'],tmp['params']['net'])]

    #Create images
    k = 1
    with alive_bar(len(tdom)) as bar:
        for t in tdom:
            #Test data
            xt_step = test_data['xt'][test_data['xt'][:,-1] == t]
            ux_step = test_data['u'][test_data['xt'][:,-1] == t,0]
            uy_step = test_data['u'][test_data['xt'][:,-1] == t,1]
            #Initialize plot
            if len(epochs) > 1:
                fig, ax = plt.subplots(int(len(epochs)/2),2,figsize = (10,5*len(epochs)/2))
            else:
                fig, ax = plt.subplots(1,1,figsize = (10,10))
            #Create
            index = 0
            if int(len(epochs)/2) > 1:
                for i in range(int(len(epochs)/2)):
                    for j in range(min(2,len(epochs))):
                        upredx_step = upred[index][test_data['xt'][:,-1] == t,0]
                        upredy_step = upred[index][test_data['xt'][:,-1] == t,1]
                        ax[i,j].plot(ux_step,uy_step,'b-',linewidth=2,label='Exact')
                        ax[i,j].plot(upredx_step,upredy_step,'r-',linewidth=2,label='Prediction')
                        ax[i,j].set_title('Epoch = ' + str(epochs[index]),fontsize=10)
                        ax[i,j].set_xlabel(' ')
                        ax[i,j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                        index = index + 1
            elif len(epochs) > 1:
                for j in range(2):
                    upredx_step = upred[index][test_data['xt'][:,-1] == t,0]
                    upredy_step = upred[index][test_data['xt'][:,-1] == t,1]
                    ax[j].plot(ux_step,uy_step,'b-',linewidth=2,label='Exact')
                    ax[j].plot(upredx_step,upredy_step,'r-',linewidth=2,label='Prediction')
                    ax[j].set_title('Epoch = ' + str(epochs[index]),fontsize=10)
                    ax[j].set_xlabel(' ')
                    ax[j].set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                    index = index + 1
            else:
                upredx_step = upred[index][test_data['xt'][:,-1] == t,0]
                upredy_step = upred[index][test_data['xt'][:,-1] == t,1]
                ax.plot(ux_step,uy_step,'b-',linewidth=2,label='Exact')
                ax.plot(upredx_step,upredy_step,'r-',linewidth=2,label='Prediction')
                ax.set_title('Epoch = ' + str(epochs[index]),fontsize=10)
                ax.set_xlabel(' ')
                ax.set_ylim([1.3 * ylo.tolist(),1.3 * yup.tolist()])
                index = index + 1


            #Title
            fig.suptitle(title + 't = ' + str(round(t,4)))
            fig.tight_layout()

            #Show and save
            fig = plt.gcf()
            fig.savefig(file_name_save + '/' + str(k) + '.png')
            k = k + 1
            plt.close()
            bar()

    #Create demo video
    os.system(ffmpeg + ' -framerate ' + str(framerate) + ' -i ' + file_name_save + '/' + '%00d.png -c:v libx264 -profile:v high -crf 20 -pix_fmt yuv420p ' + file_name_save + '/' + file_name_save + '_time_demo.mp4')

#Norm of parameters in a dictionary
def norm_par(params):
    n = 0
    for p in params:
        n = n + jnp.sum(p['B'] ** 2) + jnp.sum(p['W'] ** 2)
    return jnp.sqrt(n)

#Truncate
def truncate(x,m = 1e6):
    return jnp.where(x < m,x,m)

def DN_CSF_circle(uinitial,xl,xu,tl,tu,width,radius,Ntb = 100,N0 = 100,Nc = 50,Ntc = 50,Ns = 100,Nts = 100,epochs = 100,at_each = 10,activation = 'tanh',lrate = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,key = 0,epoch_print = 100,save = False,file_name = 'result_pinn',exp_decay = False,transition_steps = 1000,decay_rate = 0.9,demo = True,framerate = 2,ffmpeg = 'ffmpeg',c = 1e-6,ecasual = 1,w = None,grid = True,m = 1e6):
    #If demo, then save
    if demo:
        save = True

    #Define initial function and function to evaluate at boundary
    def uinit(x,t):
        u = uinitial(x,t)
        return jnp.append(u['u1'],u['u2'])

    def ubound(x,t):
        u = uinitial(x,t)
        return jnp.append(u['u1'],u['u2'],1)

    #Generate Data
    if grid:
        train_data = jd.generate_PINNdata(u = uinit,xl = xl,xu = xu,tl = tl,tu = tu,Ns = None,Nts = None,Nb = 2,Ntb = Ntb,N0 = N0,Nc = Nc,Ntc = Ntc,p = 2)
    else:
        train_data = jd.generate_PINNdata(u = uinit,xl = xl,xu = xu,tl = tl,tu = tu,Ns = None,Nts = None,Nb = 2,Ntb = Ntb,N0 = N0,Nc = Nc,Ntc = Ntc,p = 2,poss = 'random',posts = 'random',pos0 = 'random',postb = 'random',posc = 'random',postc = 'random')


    #PDE operator
    def pde(u,x,t,w = w):
        #One function for each coordinate (assuming that x and t has dimension 1 x 1 and u(x,t) has dimension 1 x 2)
        u1 = lambda x,t: u(x.reshape((x.shape[0],1)),t.reshape((t.shape[0],1)))[:,0][0]
        u2 = lambda x,t: u(x.reshape((x.shape[0],1)),t.reshape((t.shape[0],1)))[:,1][0]
        #First derivatives of each coordinate
        ux1 = jax.vmap(lambda x,t : jax.grad(lambda x,t : u1(x,t),0)(x,t))
        ux2 = jax.vmap(lambda x,t : jax.grad(lambda x,t : u2(x,t),0)(x,t))
        ut1 = jax.vmap(lambda x,t : jax.grad(lambda x,t : u1(x,t),1)(x,t))
        ut2 = jax.vmap(lambda x,t : jax.grad(lambda x,t : u2(x,t),1)(x,t))
        #Second derivative of each coordinate
        ux1_tmp = lambda x,t : jax.grad(lambda x,t : u1(x,t),0)(x,t)
        ux2_tmp = lambda x,t : jax.grad(lambda x,t : u2(x,t),0)(x,t)
        uxx1 = jax.vmap(lambda x,t : jax.grad(lambda x,t : ux1_tmp(x,t)[0],0)(x,t))
        uxx2 = jax.vmap(lambda x,t : jax.grad(lambda x,t : ux2_tmp(x,t)[0],0)(x,t))
        #Residuals
        res = (ut1(x,t) - uxx1(x,t)/(ux1(x,t) ** 2 + ux2(x,t) ** 2 + c)) ** 2 + (ut2(x,t) - uxx2(x,t)/(ux1(x,t) ** 2 + ux2(x,t) ** 2 + c)) ** 2
        #Cumulative sum
        res_cs = jnp.cumsum(res)
        #Cummulative sum until each change of time
        res_cs = jnp.append(jnp.array([0]),res_cs[(jnp.linspace(Ntc,Ntc*Nc,Ntc) - 1).astype(jnp.int32)])
        #True residual
        res = jnp.diff(res_cs)
        #Weights
        if w is None:
            w = jnp.exp(-ecasual * res_cs[:-1]/Ntc)
        #Return
        return w * res/Ntc

    #Operators to evaluate boundary conditions
    def oper_right_dir(u,x,t):
        #Enforce Dirichlet at the right boundary (fixed at point a, as the initial condition)
        res_right_dir = jnp.sum(jnp.where(x == xu,(u(x,t) - ubound(x,t)) ** 2,0),1).reshape(x.shape[0],1)
        return res_right_dir

    def oper_left_dir(u,x,t):
        #Enforce Dirichlet at the left boundary (is in the circle of radius fixed)
        res_left_dir = jnp.sum(jnp.where(x == xl,((jnp.sum(u(x,t) ** 2,1) - radius ** 2) ** 2).reshape(x.shape),0),1).reshape(x.shape[0],1)
        return res_left_dir

    def oper_neumann(u,x,t):
        #One function for each coordinate (assuming that x and t has dimension 1 x 1 and u(x,t) has dimension 1 x 2)
        u1 = lambda x,t: u(x.reshape((x.shape[0],1)),t.reshape((t.shape[0],1)))[:,0][0]
        u2 = lambda x,t: u(x.reshape((x.shape[0],1)),t.reshape((t.shape[0],1)))[:,1][0]
        #Take the derivatives in x
        ux1 = jax.vmap(lambda x,t : jax.grad(lambda x,t : u1(x,t),0)(x,t))(x,t)
        ux2 = jax.vmap(lambda x,t : jax.grad(lambda x,t : u2(x,t),0)(x,t))(x,t)
        #Enforce Neumann at the left boundary
        nS = u(x,t)/jnp.sqrt(jnp.sum(u(x,t) ** 2,1).reshape((x.shape[0],1))) #Assuming that u(x,t) \in S, compute the vector normal to S at u(x,t)
        nu = jnp.append(ux2,(-1)*ux1,1)/jnp.sqrt(ux1 ** 2 + ux2 ** 2) #Normal at u(x,y)
        ip = jnp.sum(nS * nu,1).reshape(x.shape[0],1) ** 2 #Inner product
        res_neu = jnp.where(x == xl,ip,0)
        return res_neu

    def oper_boundary(u,x,t,ll,lr,ln):
        ldir = jnp.mean(oper_left_dir(u,x,t))
        rdir = jnp.mean(oper_right_dir(u,x,t))
        neu = jnp.mean(oper_neumann(u,x,t))
        return ll*ldir + lr*rdir + ln*neu

    def initial_loss(u,x,t):
        return jnp.sum((u(x,t) - ubound(x,t)) ** 2,1)

    #Initialize architecture
    nnet = fconNN(width,get_activation(activation),key)
    forward = nnet['forward']
    params = {'net': nnet['params']}

    #Initialize weights
    xc = train_data['collocation'][:,0].reshape((train_data['collocation'].shape[0],1))
    tc = train_data['collocation'][:,1].reshape((train_data['collocation'].shape[0],1))
    xb = train_data['boundary'][:,0].reshape((train_data['boundary'].shape[0],1))
    tb = train_data['boundary'][:,1].reshape((train_data['boundary'].shape[0],1))
    x0 = train_data['initial'][:,0].reshape((train_data['initial'].shape[0],1))
    t0 = train_data['initial'][:,1].reshape((train_data['initial'].shape[0],1))
    dpde = jax.jit(jax.grad(lambda params: jnp.sum(pde(lambda x,t: forward(jnp.append(x,t,1),params['net']),xc,tc)),0))
    dl = jax.jit(jax.grad(lambda params: jnp.mean(oper_left_dir(lambda x,t: forward(jnp.append(x,t,1),params['net']),xb,tb)),0))
    dr = jax.jit(jax.grad(lambda params: jnp.mean(oper_right_dir(lambda x,t: forward(jnp.append(x,t,1),params['net']),xb,tb)),0))
    dn = jax.jit(jax.grad(lambda params: jnp.mean(oper_neumann(lambda x,t: forward(jnp.append(x,t,1),params['net']),xb,tb)),0))
    dinit = jax.jit(jax.grad(lambda params: jnp.mean(initial_loss(lambda x,t: forward(jnp.append(x,t,1),params['net']),x0,t0)),0))

    lpde = norm_par(dpde(params)['net'])
    ll = norm_par(dl(params)['net'])
    lr = norm_par(dr(params)['net'])
    ln = norm_par(dn(params)['net'])
    linit = norm_par(dinit(params)['net'])

    total = lpde + ll + lr + ln + linit
    lpde = jnp.sqrt(truncate(total/lpde,m = m))
    ll = jnp.sqrt(truncate(total/ll,m = m))
    lr = jnp.sqrt(truncate(total/lr,m = m))
    ln = jnp.sqrt(truncate(total/ln,m = m))
    linit = jnp.sqrt(truncate(total/linit,m = m))
    params = {'net': nnet['params'],'lpde': lpde,'ll': ll,'lr': lr,'ln': ln,'linit': linit}

    #Save config file
    if save:
        pickle.dump({'train_data': train_data,'epochs': epochs,'activation': activation,'init_params': params,'forward': forward,'width': width,'pde': pde,'lr': lr,'b1': b1,'b2': b2,'eps': eps,'eps_root': eps_root,'key': key,'inverse': False,'sa': False},open(file_name + '_config.pickle','wb'), protocol = pickle.HIGHEST_PROTOCOL)

    #Define loss function
    @jax.jit
    def lf(params):
        u = lambda x,t: forward(jnp.append(x,t,1),params['net'])
        return (params['lpde'] ** 2)*jnp.sum(pde(u,xc,tc)) + oper_boundary(u,xb,tb,params['ll'] ** 2,params['lr'] ** 2,params['ln'] ** 2) + (params['linit'] ** 2)*jnp.mean(initial_loss(u,x0,t0))

    #Initialize Adam Optmizer
    if exp_decay:
        lrate = optax.exponential_decay(lrate,transition_steps,decay_rate)
    optimizer = optax.adam(lrate,b1,b2,eps,eps_root)
    opt_state = optimizer.init(params)

    #Define the gradient function
    grad_loss = jax.jit(jax.grad(lf,0))

    #Define update function
    @jax.jit
    def update(opt_state,params):
        #Compute gradient
        grads = grad_loss(params)
        grads['lpde'] = -grads['lpde']
        grads['ll'] = -grads['ll']
        grads['lr'] = -grads['lr']
        grads['ln'] = -grads['ln']
        grads['linit'] = -grads['linit']
        #Calculate parameters updates
        updates, opt_state = optimizer.update(grads, opt_state)
        #Update parameters
        params = optax.apply_updates(params, updates)
        #Return state of optmizer and updated parameters
        return opt_state,params

    ###Training###
    time0 = time.time()
    #Initialize alive_bar for tracing in terminal
    with alive_bar(epochs) as bar:
        #For each epoch
        for e in range(epochs):
            #Update optimizer state and parameters
            opt_state,params = update(opt_state,params)
            #After epoch_print epochs
            if e % epoch_print == 0:
                #Compute elapsed time and current error
                l = 'Time: ' + str(round(time.time() - time0)) + ' s Loss: ' + str(jnp.round(lf(params),6))
                #Print
                print(l)
            if ((e % at_each == 0 and at_each != epochs) or e == epochs - 1):
                norm_lpde = norm_par(dpde(params)['net'])
                norm_ll = norm_par(dl(params)['net'])
                norm_lr = norm_par(dr(params)['net'])
                norm_ln = norm_par(dn(params)['net'])
                norm_linit = norm_par(dinit(params)['net'])
                total = norm_lpde + norm_ll + norm_lr + norm_ln
                params['lpde'] = 0.1*jnp.sqrt(truncate(total/norm_lpde,m = m)) + 0.9*params['lpde']
                params['ll'] = 0.1*jnp.sqrt(truncate(total/norm_ll,m = m)) + 0.9*params['ll']
                params['lr'] = 0.1*jnp.sqrt(truncate(total/norm_lr,m = m)) + 0.9*params['lr']
                params['ln'] = 0.1*jnp.sqrt(truncate(total/norm_ln,m = m)) + 0.9*params['ln']
                params['linit'] = 0.1*jnp.sqrt(truncate(total/norm_linit,m = m)) + 0.9*params['linit']
                if save:
                    #Save current parameters
                    u = lambda x,t: forward(jnp.append(x,t,1),params['net'])
                    pickle.dump({'params': params,'time': time.time() - time0,'loss': lf(params),'lpde': params['lpde'],'ll': params['ll'],'lr': params['lr'],'ln': params['ln'],'linit': params['linit'],
                    'loss_pde': pde(u,xc,tc,w = 1),'loss_initial': jnp.mean(initial_loss(u,x0,t0)),'loss_dl': jnp.mean(oper_left_dir(u,xb,tb)),
                    'loss_dr': jnp.mean(oper_right_dir(u,xb,tb)),'loss_neumann': jnp.mean(oper_neumann(u,xb,tb))},open(file_name + '_epoch' + str(e).rjust(6, '0') + '.pickle','wb'), protocol = pickle.HIGHEST_PROTOCOL)
            #Update alive_bar
            bar()

    total_time = time.time() - time0

    #Test data
    test_data = jd.generate_PINNdata(u = uinit,xl = xl,xu = xu,tl = tl,tu = tu,Ns = None,Nts = None,Nb = 2,Ntb = 2*Ntb,N0 = 2*N0,Nc = 2*Nc,Ntc = 2*Ntc,p = 2,poss = 'random',posts = 'random',pos0 = 'random',postb = 'random',posc = 'random',postc = 'random')
    xc = test_data['collocation'][:,0].reshape((test_data['collocation'].shape[0],1))
    tc = test_data['collocation'][:,1].reshape((test_data['collocation'].shape[0],1))
    xb = test_data['boundary'][:,0].reshape((test_data['boundary'].shape[0],1))
    tb = test_data['boundary'][:,1].reshape((test_data['boundary'].shape[0],1))
    x0 = test_data['initial'][:,0].reshape((test_data['initial'].shape[0],1))
    t0 = test_data['initial'][:,1].reshape((test_data['initial'].shape[0],1))

    #Evaluate residuals
    u = lambda x,t: forward(jnp.append(x,t,1),params['net'])

    res_pde = jnp.sum(pde(u,xc,tc,w = 1))/(2*Nc)
    res_dir_right = jnp.mean(oper_right_dir(u,xb,tb))
    res_neu = jnp.mean(oper_neumann(u,xb,tb))
    res_dir_left = jnp.mean(oper_left_dir(u,xb,tb))
    res_initial = jnp.mean(initial_loss(u,x0,t0))

    #Save file
    res_data = pd.DataFrame({'PDE': [res_pde.tolist()],
                             'Dirichlet_Right': [res_dir_right.tolist()],
                             'Dirichlet_Left': [res_dir_left.tolist()],
                             'Neumann': [res_neu.tolist()],
                             'initial': res_initial,
                             'time': total_time,
                             'epochs': epochs})
    res_data.to_csv(file_name + '_residuals.csv')

    if demo:
        def ucircle(x,t):
          y = 2*jnp.pi*(x - xl)/(xu - xl)
          return jnp.append(radius*jnp.sin(y),radius*jnp.cos(y),0)
        test_data = jd.generate_PINNdata(u = ucircle,xl = xl,xu = xu,tl = tl,tu = tu,Ns = Ns,Nts = Nts,Nb = 0,Ntb = 0,N0 = 0,Nc = 0,Ntc = 0,p = 2,train = False)
        demo_time_pinn2D(test_data,file_name,[epochs-1],file_name_save = file_name + '_demo',title = '',framerate = framerate,ffmpeg = ffmpeg)

    return {'params': params,'time': total_time,'loss': lf(params),'lpde': params['lpde'],'ll': params['ll'],'lr': params['lr'],'ln': params['ln'],'linit': params['linit'],
    'loss_pde': pde(u,xc,tc),'loss_initial': jnp.mean(initial_loss(u,x0,t0)),'loss_dl': jnp.mean(oper_left_dir(u,xb,tb)),
    'loss_dr': jnp.mean(oper_right_dir(u,xb,tb)),'loss_neumann': jnp.mean(oper_neumann(u,xb,tb))}
