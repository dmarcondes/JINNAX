#Functions to train NN
