#Functions to proccess the results of trained NN
