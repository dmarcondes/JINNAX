#Train Deeponets in jaxpi
from absl import logging
from alive_progress import alive_bar
from functools import partial
import jax
from jax import grad, hessian, jit, lax, vmap, jacrev, pmap
import jax.numpy as jnp
from jax.tree_util import tree_map
from jaxpi import archs
from jaxpi.evaluator import BaseEvaluator
from jaxpi.logging import Logger
from jaxpi.models import ForwardIVP
from jaxpi.samplers import BaseSampler, UniformSampler
from jaxpi.utils import ntk_fn, restore_checkpoint, save_checkpoint
from jinnax import class_csf
import matplotlib.pyplot as plt
import ml_collections
import numpy as np
import optax
import os
import pandas as pd
import random
import scipy.io
import sys
import time
import wandb

def get_base_config():
    """
    Base config file for training PINN for CSF in jaxpi

    Returns
    -------
    ml_collections config dictionary
    """
    #Get the default hyperparameter configuration.
    config = ml_collections.ConfigDict()
    # Weights & Biases
    config.wandb = wandb = ml_collections.ConfigDict()
    wandb.tag = None
    # Arch
    config.arch = arch = ml_collections.ConfigDict()
    arch.arch_name = "DeepONet"
    arch.num_branch_layers = 4
    arch.num_trunk_layers = 4
    arch.hidden_dim = 256
    arch.out_dim = 1
    arch.activation = "tanh"
    arch.reparam = None #ml_collections.ConfigDict(
        #{"type": "weight_fact", "mean": 1.0, "stddev": 0.1}
    #)
    # Optim
    config.optim = optim = ml_collections.ConfigDict()
    optim.optimizer = "Adam"
    optim.beta1 = 0.9
    optim.beta2 = 0.999
    optim.eps = 1e-8
    optim.learning_rate = 1e-3
    optim.decay_rate = 0.9
    optim.decay_steps = 2000
    optim.grad_accum_steps = 0
    optim.warmup_steps = 0
    optim.grad_accum_steps = 0
    # Training
    config.training = training = ml_collections.ConfigDict()
    training.batch_size_per_device = 4096
    # Weighting
    config.weighting = weighting = ml_collections.ConfigDict()
    weighting.scheme = "grad_norm"
    weighting.momentum = 0.9
    weighting.update_every_steps = 1000
    weighting.use_causal = False
    optim.staircase = False
    # Logging
    config.logging = logging = ml_collections.ConfigDict()
    logging.log_every_steps = 1000
    logging.log_errors = True
    logging.log_losses = True
    logging.log_weights = True
    logging.log_preds = False
    logging.log_grads = False
    logging.log_ntk = False
    # Saving
    config.saving = saving = ml_collections.ConfigDict()
    saving.save_every_steps = 1000
    saving.num_keep_ckpts = 1000000
    # # Input shape for initializing Flax models
    config.branch_input_dim = 2
    return config

# Define the model
class PI_DeepONet(ForwardIVP):
    def __init__(self, config):
        super().__init__(config)

        self.r_net = config.r_net
        self.bc_loss_operator = config.bc_loss_operator

        # Predictions over array of u and x for t fixed
        self.pred_x_fn = vmap(
            vmap(self.DeepOnet, (None, 0, 0, None)), (None, 0, 0, None)
        )

        #Prediction over array of u and t for x fixed
        self.pred_t_fn = vmap(
            vmap(self.DeepOnet, (None, 0, None, 0)), (None, 0, None, 0)
        )

        #Vmap neural net
        self.pred_fn = vmap(self.DeepOnet, (None, 0, 0, 0))

        #Vmap residual operator
        self.r_pred_fn = vmap(self.r_net, (None, 0, 0, 0))

    #DeepOnet forward function
    def DeepOnet(self, params, u, x, t):
        outputs = self.state.apply_fn(params, u, jnp.stack([x,t]))
        return outputs

    #Sensor loss
    def sensor_loss(self,params,batch):
        pred = self.r_pred_fn(
            params, batch['u0_sensor'], batch['xt_sensor'][:, 0], batch['xt_sensor'][:, 1]
        )
        return jnp.mean((pred - batch['u_sensor']) ** 2)

    #Losses
    @partial(jit, static_argnums=(0,))
    def losses(self, params, batch):
        # Compute residual loss
        #res_pred = self.r_pred_fn(
        #        params, batch['u'], batch['xt'][:, 0], batch['xt'][:, 1]
        #    )
        #res_loss = jnp.mean(res_pred ** 2)

        # Compute boundary condition loss
        bc_loss = self.bc_loss_operator(self.pred_t_fn,params,batch,self.xl,self.xu)

        # Compute sensor data loss
        sensor_loss = 0.0
        if batch['xt_sensor'] is not None:
            sensor_loss = self.sensor_loss(self.pred_fn, params, batch)

        loss_dict = {
            "res": res_loss,
            "bc": bc_loss,
            "sensor": sensor_loss
        }
        return loss_dict

#Periodic kernel
@jax.jit
def kernel_periodic(x1,x2,ls = 1,p = 1):
    return jnp.exp(-(jnp.sin(jnp.pi*jnp.abs(x1 - x2)/p) ** 2)/(2 * (ls ** 2)))

#Generate initial data
def generate_initial_data(N0,size,kernel = kernel_periodic,xl = 0,xu = 1,key = 0):
    x = jnp.linspace(xl,xu,N0)
    K = jnp.array([[kernel(x1,x2)] for x1 in x for x2 in x]).reshape((N0,N0))
    u = jax.random.multivariate_normal(key = jax.random.PRNGKey(key),mean = jnp.zeros((K.shape[0],)),cov = K,shape = (size,),method = 'svd')
    return u

class InitialDataSampler(BaseSampler):
    def __init__(self, data, batch_size,rng_key = jax.random.PRNGKey(1234)):
        super().__init__(batch_size, rng_key)
        self.data = data
        self.dim = data.shape[0]
    @partial(pmap, static_broadcasted_argnums=(0,))
    def data_generation(self, key):
        "Generates data containing batch_size samples"
        idx = jax.random.choice(key, self.dim, (self.batch_size,), replace=False)
        return self.data[idx,:]

def train(config: ml_collections.ConfigDict):
    """
    Train PINN for CSF in jaxpi
    ----------
    Parameters
    ----------
    config : ml_collections.ConfigDict

        Dictionary for training DeepONet in jaxpi

    Returns
    -------
    model, log_dict
    """
    if config.save_wandb:
        wandb_config = config.wandb
        wandb.init(project = wandb_config.project, name = wandb_config.name)

#Initialize the initial data sampler
initial_data = generate_initial_data(config.N0,int(config.size),kernel = config.kernel,xl = config.xl,xu = config.xu,key = 0)
initial_sampler = iter(InitialDataSampler(initial_data, config.training.batch_size_per_device))

# Initialize the residual sampler
dom = jnp.array([[config.xl, config.xu],[config.tl, config.tu]])
res_sampler = iter(UniformSampler(dom, config.training.batch_size_per_device))

# Initialize the model
model = PI_DeepONet(config)

#Correct shape parameters
for k in model.state.params['params'].keys():
    for k1 in (model.state.params['params'])[k].keys():
        if k1 != 'bias' and k1 != 'kernel':
            for k2 in ((model.state.params['params'])[k])[k1].keys():
                s = (((model.state.params['params'])[k])[k1])['kernel'].shape
                if len(s) == 3:
                    (((model.state.params['params'])[k])[k1])['kernel'] = (((model.state.params['params'])[k])[k1])['kernel'].reshape((s[1],s[2]))
                s = (((model.state.params['params'])[k])[k1])['bias'].shape
                if len(s) == 2:
                    (((model.state.params['params'])[k])[k1])['bias'] = (((model.state.params['params'])[k])[k1])['bias'].reshape((s[1],))
        elif k1 == 'kernel':
            s = (((model.state.params['params'])[k])[k1]).shape
            if len(s) == 3:
                (((model.state.params['params'])[k])[k1]) = (((model.state.params['params'])[k])[k1]).reshape((s[1],s[2]))
        elif k1 == 'bias':
            s = (((model.state.params['params'])[k])[k1]).shape
            if len(s) == 2:
                (((model.state.params['params'])[k])[k1]) = (((model.state.params['params'])[k])[k1]).reshape((s[1],))
# Logger
logger = Logger()

#Initialize batch data
batch = {}
if config.sensor_data is not None:
    batch['u0_sensor'] = config.sensor_data['u0_sensor']
    batch['xt_sensor'] = config.sensor_data['xt_sensor']
else:
    batch['u0_sensor'] = None
    batch['xt_sensor'] = None

    """
    # TBD Initialize evaluator
    key = jax.random.split(jax.random.PRNGKey(config.seed),4)
    x0_test = jax.random.uniform(key = jax.random.PRNGKey(key[0,0]),minval = config.xl,maxval = config.xu,shape = (config.N0,1))
    u1_0_test,u2_0_test = config.uinitial(x0_test)
    tb_test = jax.random.uniform(key = jax.random.PRNGKey(key[1,0]),minval = config.tl,maxval = config.tu,shape = (config.Nb,1))
    xc_test = jax.random.uniform(key = jax.random.PRNGKey(key[2,0]),minval = config.xl,maxval = config.xu,shape = (config.Nc ** 2,1))
    tc_test = jax.random.uniform(key = jax.random.PRNGKey(key[3,0]),minval = config.tl,maxval = config.tu,shape = (config.Nc ** 2,1))
    if config.type_csf == 'DN':
        evaluator = class_csf.DN_csf_Evaluator(config, model, x0_test, tb_test, xc_test, tc_test, u1_0_test, u2_0_test)
    elif config.type_csf == 'NN':
        evaluator = class_csf.NN_csf_Evaluator(config, model, x0_test, tb_test, xc_test, tc_test, u1_0_test, u2_0_test)
    elif config.type_csf == 'DD':
        evaluator = class_csf.DD_csf_Evaluator(config, model, x0_test, tb_test, xc_test, tc_test, u1_0_test, u2_0_test)
    elif config.type_csf == 'closed':
        evaluator = class_csf.closed_csf_Evaluator(config, model, x0_test, tb_test, xc_test, tc_test, u1_0_test, u2_0_test)
    """

    # jit warm up
    print("Training CSF...")
    start_time = time.time()
    t0 = start_time
    for step in range(config.training.max_steps):
batch['u'] = next(initial_sampler)[0,:,:]
batch['xt'] = next(res_sampler)[0,:,:]

#Try chaging to plain mlp in jaxpi
model.DeepOnet(model.state.params,batch['u'][0,:],batch['xt'][0,0],batch['xt'][0,1])
model.pred_fn(model.state.params,batch['u'],batch['xt'][:, 0],batch['xt'][:, 1])
model.state = model.step(model.state, batch)

        # Update weights if necessary
        if config.weighting.scheme in ["grad_norm", "ntk"]:
            if step % config.weighting.update_every_steps == 0:
                model.state = model.update_weights(model.state, batch)

        # Log training metrics, only use host 0 to record results
        if jax.process_index() == 0:
            if step % config.logging.log_every_steps == 0:
                # Get the first replica of the state and batch
                state = jax.device_get(tree_map(lambda x: x[0], model.state))
                batch = jax.device_get(tree_map(lambda x: x[0], batch))
                log_dict = evaluator(state, batch)
                if config.save_wandb:
                    wandb.log(log_dict, step)
                end_time = time.time()
                logger.log_iter(step, start_time, end_time, log_dict)
                start_time = end_time

        # Saving
        if config.saving.save_every_steps is not None:
            if (step + 1) % config.saving.save_every_steps == 0 or (
                step + 1
            ) == config.training.max_steps:
                ckpt_path = os.path.join(os.getcwd(),"ckpt",config.wandb.name)
                save_checkpoint(model.state, ckpt_path, keep=config.saving.num_keep_ckpts)
                if config.type_csf == 'DN':
                    if log_dict['res1_test'] < config.res_tol and log_dict['res2_test'] < config.res_tol and log_dict['ic_rel_test'] < config.ic_tol and log_dict['ld_test'] < config.dn_tol and log_dict['rd_test'] < config.dn_tol and log_dict['ln_test'] < config.dn_tol:
                        break
                elif config.type_csf == 'NN':
                    if log_dict['res1_test'] < config.res_tol and log_dict['res2_test'] < config.res_tol and log_dict['ic_rel_test'] < config.ic_tol and log_dict['ld_test'] < config.dn_tol and log_dict['rd_test'] < config.dn_tol and log_dict['ln_test'] < config.dn_tol and log_dict['rn_test'] < config.dn_tol:
                        break
                elif config.type_csf == 'DD':
                    if log_dict['res1_test'] < config.res_tol and log_dict['res2_test'] < config.res_tol and log_dict['ic_rel_test'] < config.ic_tol and log_dict['ld_test'] < config.dn_tol and log_dict['rd_test'] < config.dn_tol:
                        break
                elif config.type_csf == 'closed':
                    if log_dict['res1_test'] < config.res_tol and log_dict['res2_test'] < config.res_tol and log_dict['ic_rel_test'] < config.ic_tol:
                        break

    #Run summary
    log_dict['total_time'] = time.time() - t0
    log_dict['epochs'] = step + 1

    return model, log_dict

def bc_loss_periodic(pred_t_fn,params,batch,xl,xu):
    pred_xl = pred_t_fn(
        params, batch['u'], xl, batch['xt'][:, 1]
    )
    pred_xu = pred_t_fn(
        params, batch['u'], xu, batch['xt'][:, 1]
    )
    return jnp.mean((pred_xl - pred_xu) ** 2)

def deeponet(xl,xu,tl,tu,r_net,bc_loss_operator,sensor_data = None,kernel = kernel_periodic,file_name = 'test',N0 = 400,size = 10e4,config = None,save_wandb = False,wandb_project = 'CSF_project',seed = 534,max_epochs = 150000,res_tol = 5e-5,bc_tol = 5e-4):
    """
    Train PINN for CSF in jaxpi
    ----------
    Parameters
    ----------
    xl, xu, tl, tu : float

        Limits of the x and t domain

    file_name : str

        File name to save results

    N0, Nb : int

        Initial and boundary condition test sample size

    config : ml_collections.ConfigDict

        Config dictionary to train PINNs in jaxpi. If not provided, use basic configurations

    save_wandb : logical

        Whether to save results in wandb

    wandb_project : str

        Name of wandb project

    seed : int

        Seed for initialising neural network

    max_epochs : int

        Maximum number of epochs to train

    res_tol, bc_tol

        Tolerance on test errors for early stop

    Returns
    -------
    model, log_dict
    """

xl = 0
xu = 1
tl = 0
tu = 1
wandb_project = 'deepONet'
file_name = 'don'
seed = 0
N0 = 400
size = 10000
res_tol = 1e-3
bc_tol = 1e-3
kernel = kernel_periodic
max_epochs = 150000
r_net = None
bc_loss_operator = bc_loss_periodic
sensor_data = None

#Set config file
if config is None:
config = get_base_config()

config.wandb.project = wandb_project
config.wandb.name = file_name
config.seed = seed
config.xl = xl
config.xu = xu
config.tl = tl
config.tu = tu
config.N0 = N0
config.size = size
config.res_tol = res_tol
config.bc_tol = bc_tol
config.kernel = kernel
config.training.max_steps = max_epochs
config.bc_loss_operator = bc_loss_operator
config.r_net = r_net
config.sensor_data = sensor_data
config.weighting.init_weights = ml_collections.ConfigDict(
        {"res": 1.0,
        "bc": 1.0,
        "sensor": 1.0
        }
    )
config.trunk_input_dim = N0

    #Train model
    model, results = train(config)

    #Evaluate
    pred = evaluate(config)

    #Generate demo
    if demo:
        demo_time_CSF(pred,radius = radius,type = type,file_name_save = file_name,framerate = 10,ffmpeg = ffmpeg)

    #Print results
    pd_results = pd.DataFrame(list(results.items()))
    print(pd_results)
    pd_results.to_csv(file_name + '_results.csv')

    return results
