#Functions to define NN architectures
