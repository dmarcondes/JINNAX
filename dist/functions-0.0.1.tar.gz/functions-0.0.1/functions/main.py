#Main functions of JINNAX package
def test_function():
    print("Hello world!")

pip install git+https://github.com/dmarcondes/JINNAX
