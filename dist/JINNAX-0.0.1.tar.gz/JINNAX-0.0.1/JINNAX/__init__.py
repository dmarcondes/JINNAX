import architectures
import Main
import proccess_results
import training
